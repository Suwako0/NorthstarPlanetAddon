package com.possible_triangle.flightlib.logic

import com.possible_triangle.flightlib.api.Constants
import com.possible_triangle.flightlib.api.FlightAction
import com.possible_triangle.flightlib.api.FlightKey
import com.possible_triangle.flightlib.api.FlyingPose
import com.possible_triangle.flightlib.api.IFlightApi
import com.possible_triangle.flightlib.api.IJetpack.Context
import com.possible_triangle.flightlib.init.CommonClass
import com.possible_triangle.flightlib.mixins.ServerGamePacketListenerImplAccessor
import com.possible_triangle.flightlib.platform.Services
import net.minecraft.core.particles.ParticleTypes
import net.minecraft.resources.ResourceLocation
import net.minecraft.server.level.ServerPlayer
import net.minecraft.sounds.SoundEvent
import net.minecraft.sounds.SoundEvents
import net.minecraft.sounds.SoundSource
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.ai.attributes.AttributeModifier
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation
import net.minecraft.world.entity.player.Player
import net.minecraft.world.phys.Vec3
import kotlin.math.max
import kotlin.math.min

object JetpackLogic {
    private val DIRECTIONS =
        listOf(
            FlightKey.BACKWARD to Vec3(0.0, 0.0, -1.0).scale(0.8),
            FlightKey.FORWARD to Vec3(0.0, 0.0, 1.0).scale(1.2),
            FlightKey.LEFT to Vec3(1.0, 0.0, 0.0),
            FlightKey.RIGHT to Vec3(-1.0, 0.0, 0.0),
        )

    private val ATTRIBUTE_ID = ResourceLocation.fromNamespaceAndPath(Constants.MOD_ID, "boost")

    private val LivingEntity.SWIM_SPEED_ATTRIBUTE
        get() =
            Services.REGISTRIES.swimSpeed?.let { getAttribute(it) }

    private fun LivingEntity.removeSwimModifier() {
        SWIM_SPEED_ATTRIBUTE?.removeModifier(ATTRIBUTE_ID)
    }

    private fun LivingEntity.addSwimModifier(context: Context) {
        val attribute = SWIM_SPEED_ATTRIBUTE ?: return
        val hasModifier = attribute.getModifier(ATTRIBUTE_ID) != null

        if (!hasModifier) {
            val modifier = context.jetpack.swimModifier(context)
            if (modifier > 0) {
                attribute.addPermanentModifier(
                    AttributeModifier(
                        ATTRIBUTE_ID,
                        modifier,
                        Operation.ADD_MULTIPLIED_TOTAL,
                    ),
                )
            }
        }
    }

    fun onTick(entity: LivingEntity) {
        val context = IFlightApi.INSTANCE.findActiveJetpack(entity)

        val action = context?.let(IFlightApi.INSTANCE::currentAction)
        val swimming = action == FlightAction.BOOST_SWIMMING

        if (!swimming) {
            entity.removeSwimModifier()
        }

        if (action == null) return

        if (action == FlightAction.BOOST_ELYTRA) {
            boost(context)
        } else if (swimming) {
            entity.addSwimModifier(context)
        } else {
            uprightMovement(context, action)
        }

        spawnParticles(context)
        playSound(context)
        context.jetpack.onUse(context, action)
    }

    private fun playSound(context: Context) {
        val pos = context.entity.blockPosition()

        val volume = if (FlightKey.UP.isPressed(context.entity)) 2F else 1F
        val pitch = context.level.random.nextFloat() * 0.4F + 1F

        fun SoundEvent.play(
            volume: Float = 1F,
            pitch: Float = 1F,
        ) {
            context.level.playSound(
                null,
                pos,
                this,
                SoundSource.PLAYERS,
                volume,
                pitch,
            )
        }

        if (context.entity.isUnderWater) {
            if (context.level.gameTime % 10 != 0L) return

            val (sound, volumeModifier) =
                when (context.pose) {
                    FlyingPose.SUPERMAN -> SoundEvents.BUBBLE_COLUMN_UPWARDS_INSIDE to -0.5F
                    else -> SoundEvents.BUBBLE_COLUMN_UPWARDS_AMBIENT to 0F
                }

            sound.play(volume + volumeModifier, pitch - 0.5F)
        } else {
            if (context.level.gameTime % 5 != 0L) return
            CommonClass.SOUND_WHOOSH().play(volume, pitch)
        }
    }

    private fun boost(ctx: Context) {
        val boost = ctx.jetpack.elytraBoost()

        if (ctx.entity.level().gameTime % 15 == 0L) {
            val look = ctx.entity.lookAngle
            val factor = { i: Double -> (i * 0.1 + (i * boost - i) * 0.5) }
            ctx.entity.deltaMovement =
                ctx.entity.deltaMovement.add(
                    factor(look.x),
                    factor(look.y),
                    factor(look.z),
                )
        }
    }

    private fun uprightMovement(
        ctx: Context,
        action: FlightAction,
    ) {
        val entity = ctx.entity
        val hovering = IFlightApi.INSTANCE.isActive(ctx.jetpack.hoverType(ctx), FlightKey.TOGGLE_HOVER, entity)

        val verticalSpeed =
            if (hovering) {
                ctx.jetpack.hoverVerticalSpeed(ctx)
            } else {
                ctx.jetpack.verticalSpeed(ctx)
            }

        val horizontalSpeed =
            if (hovering) {
                if (entity.isUnderWater) {
                    0.0
                } else {
                    ctx.jetpack.hoverHorizontalSpeed(ctx)
                }
            } else {
                ctx.jetpack.horizontalSpeed(ctx)
            }

        val acceleration = ctx.jetpack.acceleration(ctx)

        val speed =
            when (action) {
                FlightAction.UP -> {
                    verticalSpeed
                }

                FlightAction.DOWN -> {
                    -verticalSpeed
                }

                FlightAction.HOVER -> {
                    if (entity.isUnderWater) {
                        0.0
                    } else {
                        ctx.jetpack.hoverSpeed(ctx)
                    }
                }

                else -> {
                    error("invalid flight action set")
                }
            }

        if (entity is Player) {
            DIRECTIONS.filter { it.first.isPressed(entity) }.forEach {
                val vec = Vec3(it.second.x, 0.0, it.second.z).scale(horizontalSpeed)
                entity.moveRelative(1F, vec)
            }
        }

        val motion = entity.deltaMovement

        val motionY =
            if (speed <= 0) {
                max(motion.y, speed)
            } else {
                min(motion.y + acceleration, speed)
            }

        entity.setDeltaMovement(motion.x, motionY, motion.z)

        if (entity is ServerPlayer) {
            entity.fallDistance = 0F
            (entity.connection as ServerGamePacketListenerImplAccessor).setAboveGroundTickCount(0)
        }
    }

    private fun spawnParticles(context: Context) {
        val level = context.level
        if (!level.isClientSide()) return

        val thrusters = context.jetpack.getThrusters(context) ?: return
        val yaw = (context.entity.yBodyRot / 180 * -Math.PI).toFloat()
        val pitch = (context.entity.xRot / 180 * -Math.PI).toFloat()
        val xRot =
            when (context.pose) {
                FlyingPose.SUPERMAN -> pitch
                FlyingPose.UPRIGHT -> 0F
            }
        thrusters
            .map { it.xRot(xRot) }
            .map { it.yRot(yaw) }
            .map { it.scale(context.entity.scale.toDouble()) }
            .forEach { pos ->
                val particle =
                    if (context.entity.isUnderWater) {
                        ParticleTypes.BUBBLE
                    } else {
                        context.jetpack.createParticles()
                    }
                level.addParticle(
                    particle,
                    context.entity.x + pos.x,
                    context.entity.y + pos.y,
                    context.entity.z + pos.z,
                    0.0,
                    -1.0,
                    0.0,
                )
            }
    }
}
