package com.possible_triangle.flightlib.api

import net.minecraft.client.KeyMapping
import net.minecraft.util.StringRepresentable
import net.minecraft.world.entity.LivingEntity
import org.lwjgl.glfw.GLFW
import java.util.*

enum class FlightKey(
    val toggle: Boolean,
    val register: Boolean = false,
    val defaultKey: Int? = null,
    val default: Boolean = false,
) : StringRepresentable {
    UP(false),
    LEFT(false),
    RIGHT(false),
    FORWARD(false),
    BACKWARD(false),
    TOGGLE_ACTIVE(true, register = true, default = true, defaultKey = GLFW.GLFW_KEY_G),
    TOGGLE_HOVER(true, register = true, defaultKey = GLFW.GLFW_KEY_H),
    ACTIVATE_ELYTRA(false, register = true),
    ;

    lateinit var binding: Optional<KeyMapping>

    fun isPressed(entity: LivingEntity) = IFlightApi.INSTANCE.isPressed(this, entity)

    override fun getSerializedName() = name.lowercase()
}
