/*
 * Copyright (C) 2025  DragonsPlus
 * SPDX-License-Identifier: LGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package plus.dragons.createenchantmentindustry.integration.apothic_enchanting.common.registry;

import static plus.dragons.createdragonsplus.common.registry.CDPFluids.COMMON_TAGS;
import static plus.dragons.createenchantmentindustry.common.CEICommon.REGISTRATE;

import com.simibubi.create.api.effect.OpenPipeEffectHandler;
import com.simibubi.create.api.event.PipeCollisionEvent;
import com.tterrag.registrate.providers.RegistrateTagsProvider;
import com.tterrag.registrate.util.entry.FluidEntry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.core.dispenser.DispenseItemBehavior;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.DispensibleContainerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.pathfinder.PathType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.neoforge.common.SoundActions;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidInteractionRegistry;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.registries.DeferredHolder;
import plus.dragons.createdragonsplus.common.fluids.dragonBreath.DragonBreathFluidType;
import plus.dragons.createdragonsplus.common.fluids.dragonBreath.DragondBreathLiquidBlock;
import plus.dragons.createdragonsplus.common.fluids.dragonBreath.DragonsBreathOpenPipeEffect;
import plus.dragons.createdragonsplus.common.registry.CDPFluids;
import plus.dragons.createdragonsplus.common.registry.CDPItems;
import plus.dragons.createdragonsplus.data.tag.IntrinsicTagRegistry;
import plus.dragons.createdragonsplus.data.tag.ItemTagRegistry;
import plus.dragons.createenchantmentindustry.common.CEICommon;
import plus.dragons.createenchantmentindustry.common.registry.CEIFluids;

public class CEIAFluids {
    public static final ModTags MOD_TAGS = new ModTags();
    public static final ModItemTags MOD_ITEM_TAGS = new ModItemTags();
    private static boolean itemTagsRegistered;
    public static final FluidEntry<BaseFlowingFluid.Source> INFUSED_DRAGON_BREATH = new FluidEntry<>(REGISTRATE,
            DeferredHolder.create(Registries.FLUID, REGISTRATE.asResource("infused_dragon_breath")));
    public static final FluidEntry<BaseFlowingFluid.Flowing> INFUSED_DRAGON_BREATH_FLOWING = REGISTRATE
            .fluid("infused_dragon_breath",
                    REGISTRATE.asResource("fluid/infused_dragon_breath_still"), // TODO texture update. Also need texture of bucket.
                    REGISTRATE.asResource("fluid/infused_dragon_breath_flow"),
                    DragonBreathFluidType.create()) // TODO need redesign fluid effect
            .asOptional()
            .lang("Infused Dragon's Breath")
            .properties(properties -> properties
                    .rarity(Rarity.EPIC)
                    .density(3100)
                    .viscosity(6100)
                    .lightLevel(15)
                    .motionScale(0.07)
                    .supportsBoating(true)
                    .canSwim(false)
                    .canDrown(false)
                    .pathType(PathType.DAMAGE_OTHER)
                    .adjacentPathType(null)
                    .sound(SoundActions.FLUID_VAPORIZE, SoundEvents.DRAGON_FIREBALL_EXPLODE)
                    .sound(SoundActions.BUCKET_EMPTY, SoundEvents.BUCKET_EMPTY_LAVA)
                    .sound(SoundActions.BUCKET_FILL, SoundEvents.BUCKET_FILL_LAVA))
            .fluidProperties(properties -> properties
                    .explosionResistance(200F)
                    .levelDecreasePerBlock(2)
                    .slopeFindDistance(2)
                    .tickRate(10))
            .source(BaseFlowingFluid.Source::new)
            .block(DragondBreathLiquidBlock::new)
            .lang("Infused Dragon's Breath")
            .build()
            .bucket()
            .properties(properties -> properties.rarity(Rarity.EPIC))
            .lang("Infused Dragon's Breath Bucket")
            .build()
            .register();

    public static class ModTags extends IntrinsicTagRegistry<Fluid, RegistrateTagsProvider.IntrinsicImpl<Fluid>> {
        public final TagKey<Fluid> infusing_ingredients = tag("infusing/ingredients", "Infusing Reagent");

        public ModTags() {
            super(CEICommon.ID, Registries.FLUID);
        }

        @Override
        public void generate(RegistrateTagsProvider.IntrinsicImpl<Fluid> provider) {
            super.generate(provider);
            provider.addTag(COMMON_TAGS.dragonBreath)
                    .addOptional(CEICommon.asResource("infused_dragon_breath"))
                    .addOptional(CEICommon.asResource("flowing_infused_dragon_breath"));
            provider.addTag(infusing_ingredients)
                    .add(CEIFluids.EXPERIENCE.get())
                    .add(CEIFluids.EXPERIENCE_FLOWING.get());
        }
    }

    public static class ModItemTags extends ItemTagRegistry {
        public ModItemTags() {
            super(CEICommon.ID);
            addOptional(Tags.Items.BUCKETS, CEICommon.asResource("infused_dragon_breath_bucket"));
            addOptional(CDPItems.COMMON_TAGS.dragonBreathBuckets, CEICommon.asResource("infused_dragon_breath_bucket"));
        }
    }

    public static void register(IEventBus modBus) {
        modBus.register(CEIAFluids.class);
        NeoForge.EVENT_BUS.register(Events.class);
        REGISTRATE.registerFluidTags(MOD_TAGS);
    }

    public static synchronized void registerItemTags() {
        if (itemTagsRegistered)
            return;
        itemTagsRegistered = true;
        REGISTRATE.registerItemTags(MOD_ITEM_TAGS);
    }

    @SubscribeEvent
    public static void setup(final FMLCommonSetupEvent event) {
        event.enqueueWork(CEIAFluids::registerFluidInteractions);
        event.enqueueWork(CEIAFluids::registerOpenPipeEffects);
        event.enqueueWork(CEIAFluids::registerDispenserBehavior);
    }

    public static void registerDispenserBehavior() {
        DispenseItemBehavior fluidDispenserBehavior = new DefaultDispenseItemBehavior() {
            private final DefaultDispenseItemBehavior defaultDispenseItemBehavior = new DefaultDispenseItemBehavior();

            public ItemStack execute(BlockSource source, ItemStack itemStack) {
                DispensibleContainerItem dispensiblecontaineritem = (DispensibleContainerItem) itemStack.getItem();
                BlockPos blockpos = source.pos().relative(source.state().getValue(DispenserBlock.FACING));
                Level level = source.level();
                if (dispensiblecontaineritem.emptyContents(null, level, blockpos, null, itemStack)) {
                    dispensiblecontaineritem.checkExtraContent(null, level, itemStack, blockpos);
                    return this.consumeWithRemainder(source, itemStack, new ItemStack(Items.BUCKET));
                } else {
                    return this.defaultDispenseItemBehavior.dispense(source, itemStack);
                }
            }
        };
        DispenserBlock.registerBehavior(INFUSED_DRAGON_BREATH.getBucket().get(), fluidDispenserBehavior);
    }

    public static class Events {
        @SubscribeEvent
        public static void onPipeCollisionFlow(final PipeCollisionEvent.Flow event) {
            FluidType first = event.getFirstFluid().getFluidType();
            FluidType second = event.getSecondFluid().getFluidType();
            if (first == NeoForgeMod.LAVA_TYPE.value() && second == INFUSED_DRAGON_BREATH.getType()) {
                event.setState(Blocks.END_STONE.defaultBlockState());
            } else if (second == NeoForgeMod.LAVA_TYPE.value() && first == INFUSED_DRAGON_BREATH.getType()) {
                event.setState(Blocks.END_STONE.defaultBlockState());
            }
        }

        @SubscribeEvent
        public static void onPipeCollisionSpill(final PipeCollisionEvent.Spill event) {
            Fluid world = event.getWorldFluid();
            Fluid pipe = event.getPipeFluid();
            FluidType worldType = world.getFluidType();
            FluidType pipeType = pipe.getFluidType();
            if (worldType == NeoForgeMod.LAVA_TYPE.value() && pipeType == INFUSED_DRAGON_BREATH.getType()) {
                if (world.isSource(world.defaultFluidState())) {
                    event.setState(Blocks.OBSIDIAN.defaultBlockState());
                } else {
                    event.setState(Blocks.END_STONE.defaultBlockState());
                }
            } else if (pipeType == NeoForgeMod.LAVA_TYPE.value() && worldType == INFUSED_DRAGON_BREATH.getType()) {
                if (pipe.isSource(pipe.defaultFluidState())) {
                    event.setState(Blocks.OBSIDIAN.defaultBlockState());
                } else {
                    event.setState(Blocks.END_STONE.defaultBlockState());
                }
            }
        }
    }

    static void registerFluidInteractions() {
        FluidInteractionRegistry.addInteraction(NeoForgeMod.LAVA_TYPE.value(), new FluidInteractionRegistry.InteractionInformation(
                INFUSED_DRAGON_BREATH.getType(), fluidState -> fluidState.isSource() ? Blocks.CRYING_OBSIDIAN.defaultBlockState() : Blocks.END_STONE.defaultBlockState()));
        FluidInteractionRegistry.addInteraction(CDPFluids.DRAGON_BREATH.getType(), new FluidInteractionRegistry.InteractionInformation(
                INFUSED_DRAGON_BREATH.getType(), fluidState -> fluidState.isSource() ? Blocks.OBSIDIAN.defaultBlockState() : Blocks.END_STONE.defaultBlockState()));
        FluidInteractionRegistry.addInteraction(INFUSED_DRAGON_BREATH.getType(), new FluidInteractionRegistry.InteractionInformation(
                CDPFluids.DRAGON_BREATH.getType(), fluidState -> fluidState.isSource() ? Blocks.AMETHYST_BLOCK.defaultBlockState() : Blocks.END_STONE.defaultBlockState()));
    }

    static void registerOpenPipeEffects() {
        OpenPipeEffectHandler.REGISTRY.register(INFUSED_DRAGON_BREATH.getSource(), new DragonsBreathOpenPipeEffect());
    }
}
